import React, { useState } from "react";
import { IoLocationSharp } from "react-icons/io5";
import {
  FiShoppingCart,
  FiHeart,
  FiBell,
  FiUser,
  FiSearch,
  FiMenu,
  FiSmartphone,
  FiWifi,
  FiCamera,
  FiCpu,
} from "react-icons/fi";
import { IoIosLaptop } from "react-icons/io";
import { MdCategory, MdPhone, MdOutlineNavigateNext } from "react-icons/md";
import "../styles/navbar.css";
import { Link } from "react-router-dom";

function Navbar() {
  const [modal, setModal] = useState(false);

  return (
    <>
      <nav className="navbar">
        <div className="container">
          
          <div className="navbar-main ">
            <div className="navbar-brand">
              <img src="/navbarlogo.png" alt="" />
            </div>

            <div className="navbar-search">
              <input
                type="text"
                placeholder="All categories - Phones and tablets"
              />
              <button>
                <FiSearch className="icon" />
                Search
              </button>
            </div>

            <div className="navbar-actions">
              <button className="action-btn">
                <FiUser className="icon" />
                <Link to="/signup">
                  <span>Sign Up</span>
                </Link>
              </button>
              <button className="action-btn">
                <FiBell className="icon" />
                <span>Notifications</span>
              </button>
              <button className="action-btn">
                <FiHeart className="icon" />
                <span>Favorites</span>
              </button>
              <button className="action-btn cart">
                <FiShoppingCart className="icon" />
                <span>Cart</span>
                <span className="badge">0</span>
              </button>
            </div>
          </div>

          <div className="navbar-menu ">
            <button
              type="button"
              className="menu-btn"
              onClick={() => setModal((prev) => !prev)}
            >
              <FiMenu className="icon" />
              <MdCategory className="icon" />
              <span>Categories</span>
            </button>
            <div className="navbar-links">
              <a href="#stores">Our Stores</a>
              <a href="#mono">Mono Brands</a>
              <a href="#phones">Phones & Tablets</a>
              <a href="#notebooks">Laptops</a>
              <a href="#accessories">Accessories</a>
              <a href="#equipment">Network Equipment</a>
              <a href="#services">Office Equipment</a>
            </div>
          </div>

          <div
            className={`category-modal ${modal ? "open" : " "}`}
            onClick={() => setModal(false)}
          >
            <div className="category-modal-backdrop" />
            <div
              className="category-modal-panel"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="category-modal-grid">
                <button
                  type="button"
                  className="modal-close"
                  onClick={() => setModal(false)}
                  aria-label="Close categories"
                >
                  ×
                </button>
                <div className="category-modal-list">
                  <div className="category-modal-title">Categories</div>
                  <a href="#phones">
                    <FiSmartphone className="list-icon" /> Phones & Tablets
                    <MdOutlineNavigateNext className="navigate-icon" />
                  </a>
                  <a href="#notebooks">
                    <IoIosLaptop className="list-icon" /> Laptops
                    <MdOutlineNavigateNext className="navigate-icon" />
                  </a>
                  <a href="#network">
                    <FiWifi className="list-icon" /> Network Equipment
                    <MdOutlineNavigateNext className="navigate-icon" />
                  </a>
                  <a href="#video">
                    <FiCamera className="list-icon" /> Video Surveillance
                    <MdOutlineNavigateNext className="navigate-icon" />
                  </a>
                  <a href="#computers">
                    <FiCpu className="list-icon" /> Computers
                    <MdOutlineNavigateNext className="navigate-icon" />
                  </a>
                  <a href="#office">
                    <FiUser className="list-icon" /> Office Equipment
                    <MdOutlineNavigateNext className="navigate-icon" />
                  </a>
                </div>
                <div className="category-modal-right">
                  <div className="category-modal-right-panel">
                    <div className="category-modal-title">
                      Network Equipment
                    </div>
                    <div className="category-sublist">
                      <a href="#switches">Switches</a>
                      <a href="#wifi-points">Wi-Fi Access Points</a>
                      <a href="#media-converters">Media Converters</a>
                      <a href="#adsl">ADSL Routers</a>
                      <a href="#adapters">Network Adapters</a>
                      <a href="#repeaters">Signal Repeaters</a>
                    </div>
                  </div>
                  <div className="category-modal-preview">
                    <img
                      src="/wifi.png"
                      alt="WiFi Router"
                      className="category-preview-image"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
}

export default Navbar;
