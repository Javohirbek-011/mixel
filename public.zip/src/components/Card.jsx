import React from "react";
import { FiShoppingCart, FiHeart } from "react-icons/fi";
import { RiScalesFill } from "react-icons/ri";

import "../styles/card.css";

function Card() {
  return (
    <div className="product-card">
      <div className="card-image-container">
        <img src="/tel.png" alt="Smart Fitness Watch" className="card-image" />
        <span className="discount-badge">-20%</span>
      </div>

      <div className="card-details">
        <div className="card-info">
          <span className="original-price">$249.99</span>
          <span className="price">$199.99</span>
        </div>

        <h3 className="product-name">Haylou RT-LS05S Smart Watch</h3>

        <div className="card-actions">
          <button className="action-icon cart-btn" title="Add to cart">
            <FiShoppingCart />
          </button>
          <button className="action-icon wishlist-btn" title="Add to wishlist">
            <FiHeart />
          </button>
          <button className="action-icon compare-btn" title="Compare">
            <RiScalesFill />
          </button>
        </div>
      </div>
    </div>
  );
}

export default Card;
